<?php
$con = mysql_connect("mcl.mju.ac.kr","root","kjs738");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
  mysql_select_db("capstone",$con);
  ?>