 <link rel="stylesheet" href="./rankBar/rankBar.css" type="text/css" media="screen" />
  <script src="./rankBar/rankBar.js" type="text/javascript" ></script>
 
<div id="rankNavi">
	<ul>
		<li>
			<a>
				<span id="r1" class="rankVal">1</span>
				<span class="rankCont">이쿠닉스</span>
			</a>
		</li>
		<li>
			<a>
				<span id="r2" class="rankVal">2</span>
				<span class="rankCont">컴퓨터 개발자 커뮤니티</span>
			</a>
		</li>
		<li>
			<a>
				<span id="r3" class="rankVal">3</span>
				<span class="rankCont">MyeonJi Yongin Campus</span>
			</a>
		</li>
		<li>
			<a>
				<span id="r4" class="rankVal">4</span>
				<span class="rankCont">MyeonJi Computer Engineering</span>
			</a>
		</li>
		<li>
			<a>
				<span id="r5" class="rankVal">5</span>
				<span class="rankCont">MyeongJi University</span>
			</a>
		</li>
		<li>
			<a>
				<span id="r6" class="rankVal">6</span>
				<span class="rankCont">asdfasdfzxcvzxcv</span>
			</a>
		</li>
		<li>
			<a>
				<span id="r7" class="rankVal">7</span>
				<span class="rankCont">asdasdasd</span>
			</a>
		</li>
		<li>
			<a>
				<span id="r8" class="rankVal">8</span>
				<span class="rankCont">asdasdasd</span>
			</a>
		</li>
		<li>
			<a>
				<span id="r9" class="rankVal">9</span>
				<span class="rankCont">vasdfafrawef</span>
			</a>
		</li>
		<li>
			<a>
				<span id="r10" class="rankVal">10</span>
				<span class="rankCont">zxczxczcxzvd</span>
			</a>
		</li>
	</ul>
</div>
