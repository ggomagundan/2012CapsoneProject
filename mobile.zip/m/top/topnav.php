 <link rel="stylesheet" href="./top/topnav.css" type="text/css" media="screen" />
 
<div id="svcNavi">
	<ul>
		<li>
			<a class="search" href="">Search</a>
		</li>
		
		<li>
			<a class="mail" href="">Community</a>
		</li>
	
		<li>
			<a class="cafe" href="">Status</a>
		</li>
		
		<li>
			<a class="shop" href="">News</a>
		</li>
		
		<li>
			<a class="news" href="">News</a>
		</li>
	</ul>
</div>