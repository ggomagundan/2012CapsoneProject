<link rel="stylesheet" href="./adbar/top_adbar.css" type="text/css" media="screen" />
<hr />
<a href="">
<div id="top_adbar">
	
		<img id="t_adbar" src="" alt="adbar">
	
</div>
</a>	
<script type="text/javascript">
		var rannumber=Math.floor(Math.random()*4)+1;
		 
		 var img_src = "./images/adbar"+rannumber+".png";
		$('#t_adbar').attr('src',img_src);
		if(rannumber == 1){
			$('#top_adbar').css('background-color','#96e6ed');	
		}else if(rannumber ==2){
			$('#top_adbar').css('background-color','#2880e3');
		}else if(rannumber == 3){
			$('#top_adbar').css('background-color','#9880e3');
		}else if(rannumber ==4){
			$('#top_adbar').css('background-color','#3f3d9d');
		}else if(rannumber ==5){
			$('#top_adbar').css('background-color','#1f1d8b');
		}else if(rannumber ==6){
			$('#top_adbar').css('background-color','#00d0ca');
		}else if(rannumber ==7){
			$('#top_adbar').css('background-color','#a9a2d0');
		}else if(rannumber ==8){
			$('#top_adbar').css('background-color','#6797db');
		}
			
	</script>
 <hr />