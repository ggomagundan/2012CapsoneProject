<link rel="stylesheet" href="./footer/footer.css" />
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.1.0/jquery.mobile-1.1.0.min.css" />
<footer>
	 
	<div id="mFooter" data-theme="d" data-role="footer" data-position="fixed" > 
			<div data-role="navbar">
		<ul>
			<li><a href="#" class="ui-btn-active ui-state-persist">One</a></li>
			<li><a href="#">Two</a></li>
			<li><a href="#">Three</a></li>
		</ul>
		
	</div><!-- /navbar -->
	
	

</div>
	
 
</footer>
