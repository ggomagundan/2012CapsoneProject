<link rel="stylesheet" href="./info/info.css" type="text/css" media="screen" />

<div class="info">
	<a href=""><span>Ruara</span></a>
	| 
	<a href=""><span> 약관</span></a>
	|
	<a href=""><span> 개인 정보 </span></a>
</div> 
